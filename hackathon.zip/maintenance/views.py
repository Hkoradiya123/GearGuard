from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import MaintenanceRecord


@login_required
def maintenance_list(request):
    records = (
        MaintenanceRecord.objects
        .select_related('equipment', 'equipment__category')
        .order_by('-service_date')
    )
    return render(request, 'maintenance/list.html', {'records': records})
